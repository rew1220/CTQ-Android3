package com.example.callme;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class JavaLinearLayoutCode extends AppCompatActivity{
//LinearLayout을 xml이 아닌 java로 화면 구성하는 코드
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        //layout 설정 및 방향 설정
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams
                (ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
        //속성을 지정한 params 변수(가로 꽉 세로 내용에 맞게)
        Button button1 = new Button(this);
        button1.setText("버튼1");
        button1.setLayoutParams(params);
        //params 변수의 속성과 같은 속성의 button
        mainLayout.addView(button1);
        //레이아웃에 (버튼)추가
        setContentView(mainLayout);
        //레이아웃을 화면에 설정
    }
}
