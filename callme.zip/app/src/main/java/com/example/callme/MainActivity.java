package com.example.callme;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onTestButtonClicked(View v){
        Toast.makeText(this, "클릭됨!", Toast.LENGTH_SHORT).show();
        //Toast : 아래쪽에 나타나는 작은 알림

    }
    public void onSiteButtonClicked(View v){
        Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://google.com"));
        startActivity(myIntent);
    }
    public void onCallButtonClicked(View v){
        Intent myIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:010-1234-5768"));
        startActivity(myIntent);
    }
}